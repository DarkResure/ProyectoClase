package com.example.juegopulsacion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Juegos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juegos);
    }

    public void PulsacionConinua(View v){
        Intent l = new Intent(this, PulsacionContinua.class);
        startActivity(l);
    }

    /*public void PulsacionOrientada(View v){

    }
    public void PulsacionPropuesta(View v){

    }*/
}
