package com.example.juegopulsacion;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class AdminSQL extends SQLiteOpenHelper {


    public AdminSQL(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //db.execSQL("drop table partidas",null);
        db.execSQL("create table partidas(idpartida int primary key,juego String, idPaciente String, idSanitario String,tiempoJuego int, tiempo int, pulsaciones int, fecha String," +
                "foreign key (idPaciente) references paciente(idPaciente), foreign key (idSanitario) references usuario(idSanitario))");
        db.execSQL("insert into partidas values(1,\"Pulsacion Continua\",\"P-001\",\"E-001\",60,60,390,\"Thu Feb 27 19:20:00 GMT 2020\")");
        db.execSQL("create table usuarios(idSanitario String primary key, nombre String)");
        db.execSQL("insert into usuarios values(\"A-001\",\"Pepe\")");
        db.execSQL("insert into usuarios values(\"M-001\",\"Jose\")");
        db.execSQL("insert into usuarios values(\"E-001\",\"Juan\")");
        db.execSQL("create table pacientes(idPaciente String primary key, nombre String)");
        db.execSQL("insert into pacientes values(\"P-001\",\"Joder\")");
        db.execSQL("insert into pacientes values(\"P-002\",\"No\")");
        db.execSQL("insert into pacientes values(\"P-003\",\"Se\")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //db.execSQL("DROP TABLE IF EXISTS " + "partidas");
        //onCreate(db);
    }
}
