package com.example.juegopulsacion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class DarAlta extends AppCompatActivity {
    private EditText et1, et2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dar_alta);
        et1 = findViewById(R.id.id);
        et2 = findViewById(R.id.name);
    }

    public void Alta(View v){
        Toast t = Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT);
        char inicial = et1.getText().toString().toUpperCase().charAt(0);
        if(inicial == 'P' || inicial == 'A'|| inicial == 'M'|| inicial == 'E'){
            AdminSQL admin = new AdminSQL(this,"administracion", null, 1);
            SQLiteDatabase bd = admin.getWritableDatabase();
            String id = et1.getText().toString();
            String nombre = et2.getText().toString();
            ContentValues registro = new ContentValues();
            registro.put("id", id);
            registro.put("nombre", nombre);
            String[] args = {id};
            if(inicial == 'P'){
                Cursor fila = bd.rawQuery("select idPaciente  from pacientes where idPaciente=?", args);
                fila.moveToFirst();
                if(fila.isAfterLast()){
                    bd.insert("pacientes", null, registro);
                    et1.setText("");
                    et2.setText("");
                    t = Toast.makeText(getApplicationContext(),"Se han guardado los datos",Toast.LENGTH_SHORT);
                    t.show();
                }else{
                    t = Toast.makeText(getApplicationContext(),"Paciente ya existente",Toast.LENGTH_SHORT);
                    t.show();
                }
            }else{
                Cursor fila = bd.rawQuery("select idSanitario from usuarios where idSanitario=?", args);
                fila.moveToFirst();
                if(fila.isAfterLast()){
                    bd.insert("usuarios", null, registro);
                    et1.setText("");
                    et2.setText("");
                    t = Toast.makeText(getApplicationContext(),"Se han guardado los datos",Toast.LENGTH_SHORT);
                    t.show();
                }else{
                    t = Toast.makeText(getApplicationContext(),"Paciente ya existente",Toast.LENGTH_SHORT);
                    t.show();
                }
            }
            bd.close();

        }else{
            t = Toast.makeText(getApplicationContext(),"Introduzca un ID válido",Toast.LENGTH_SHORT);
            t.show();
        }
    }
    public void Volver(View v){{
        finish();
    }
    }
}
