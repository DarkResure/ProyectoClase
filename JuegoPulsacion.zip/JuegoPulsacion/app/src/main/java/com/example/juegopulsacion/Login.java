package com.example.juegopulsacion;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    private EditText pass,user;
    private TextView tv1;
    private Spinner spn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        spn = (Spinner)findViewById(R.id.spinner);
        user=(EditText)findViewById(R.id.user);
        tv1=(TextView)findViewById(R.id.tv1);
        String []opciones={"Administrador","Médico","Enfermero"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, opciones);
        spn.setAdapter(adapter);
    }

    public void comprobar(View view) {
            Toast t = Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT);;
            String rol = spn.getSelectedItem().toString();
            if(rol.charAt(0) != user.getText().charAt(0)){
                t = Toast.makeText(getApplicationContext(),"Compruebe que se ha autentificado en el rol correspondiente",Toast.LENGTH_SHORT);
                t.show();

            } else{
                MainActivity.logged=user.getText().toString();
                AdminSQL admin = new AdminSQL(this,"Administracion",null,1);
                SQLiteDatabase bd = admin.getWritableDatabase();
                String[] args = {user.getText().toString()};
                Cursor fila = bd.rawQuery("select idSanitario  from usuarios where idSanitario=?", args);
                if(fila.isAfterLast()){
                    t = Toast.makeText(getApplicationContext(),"Usuario incorrecto",Toast.LENGTH_SHORT);
                    t.show();
                }else{
                    fila.moveToFirst();
                    MainActivity.logged=user.getText().toString();
                    t = Toast.makeText(getApplicationContext(),"Usuario correcto",Toast.LENGTH_SHORT);
                    t.show();
                    finish();
                }
            }


    }
    public void Volver(View v){
        finish();
    }
}
