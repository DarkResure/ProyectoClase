package com.example.juegopulsacion;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Registros extends AppCompatActivity {
    private EditText et1;
    private ListView lv1;
    private ArrayList<String> partidas;
    private ArrayAdapter<String> adaptador1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registros);
        et1 = (EditText) findViewById(R.id.editText);
        partidas =new ArrayList<String>();
        lv1 = (ListView) findViewById(R.id.list);
        adaptador1=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, partidas);
        lv1.setAdapter(adaptador1);
    }

    public void Historial (View v){
        partidas.clear();
        adaptador1.notifyDataSetChanged();
        Toast t = Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT);
        AdminSQL admin = new AdminSQL(this,"administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String id = et1.getText().toString();
        String[] args = {id};
        Cursor fila = bd.rawQuery("select * from partidas where idPaciente=?",args);
        fila.moveToFirst();
        if(fila.isAfterLast()){
            t = Toast.makeText(getApplicationContext(),"No existe el paciente o no ha realizado partidas",Toast.LENGTH_SHORT);
            t.show();
        }else{
            while(!fila.isAfterLast()){
                partidas.add("Partida: "+fila.getString(0));
                partidas.add("Juego: "+fila.getString(1));
                partidas.add("Id Sanitario: "+fila.getString(3));
                partidas.add("Tiempo de Juego: "+fila.getString(4));
                partidas.add("Tiempo: "+fila.getString(5));
                partidas.add("Pulsaciones: "+fila.getString(6));
                partidas.add("Pulsaciones por minuto"+(fila.getInt(6)/fila.getInt(4)));
                partidas.add("Fecha: "+fila.getString(7));
                partidas.add("-------------------");
                fila.moveToNext();
            }
            adaptador1.notifyDataSetChanged();
        }


    }



    public void Volver (View v){
        finish();
    }
}
