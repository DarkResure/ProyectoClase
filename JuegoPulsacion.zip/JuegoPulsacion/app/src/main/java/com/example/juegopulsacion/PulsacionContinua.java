package com.example.juegopulsacion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class PulsacionContinua extends AppCompatActivity {
    private TextView tv1;
    private EditText et1;
    private Button btn1;
    private CountDownTimer timer;
    private final long TIMER_TIME = 60000;
    private boolean terminado = true;
    private int cont = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pulsacion_continua);
        et1 = (EditText) findViewById(R.id.paciente);
        tv1 = (TextView) findViewById(R.id.time);
        btn1 = (Button) findViewById(R.id.smash);
        tv1.setText(""+TIMER_TIME/1000);
    }

    public void Smash(View v){
        if(!terminado){
            cont++;
            btn1.setText(""+cont);
        }

    }

    public void Empezar(View v){
        Toast t = Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT);
        if(et1.getText().toString().charAt(0) != 'P'){
            t = Toast.makeText(getApplicationContext(),"Introduzca un identificador válido",Toast.LENGTH_SHORT);
            t.show();
        }else{
            AdminSQL admin = new AdminSQL(this,"administracion", null, 1);
            SQLiteDatabase bd = admin.getWritableDatabase();
            String id = et1.getText().toString();
            String[] args = {id};
            Cursor fila = bd.rawQuery("select idPaciente  from pacientes where idPaciente=?", args);
            fila.moveToFirst();
            if(fila.isAfterLast()){
                t = Toast.makeText(getApplicationContext(),"Paciente no encontrado",Toast.LENGTH_SHORT);
                t.show();
            }else{
                terminado = false;
                cont = 0;
                timer = new CountDownTimer(TIMER_TIME,1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        tv1.setText("" +millisUntilFinished / 1000);
                    }

                    @Override
                    public void onFinish() {
                        Guardar();
                        terminado = true;

                    }
                }.start();
            }
        }

    }
    public void Guardar(){
        Toast t = Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT);
        AdminSQL admin = new AdminSQL(this,"administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        int idPartida;
        String idPaciente = et1.getText().toString();
        String idSanitario = MainActivity.logged;
        int  tiempoJuego =(int) (TIMER_TIME / 1000);
        int tiempo = (int)(TIMER_TIME / 1000);
        String fecha = Calendar.getInstance().getTime().toString();
        Cursor fila = bd.rawQuery("select idPartida from partidas",null);
        fila.moveToFirst();
        if(fila.isAfterLast()){
            idPartida = 1;
        }else{
            fila.moveToLast();
            idPartida = fila.getInt(0) + 1;
        }
        ContentValues registro = new ContentValues();
        registro.put("idPartida", idPartida);
        registro.put("juego", "Pulsacion continua");
        registro.put("idPaciente", idPaciente);
        registro.put("idSanitario", idSanitario);
        registro.put("tiempoJuego", tiempoJuego);
        registro.put("tiempo", tiempo);
        registro.put("pulsaciones",""+cont);
        registro.put("fecha", fecha);
        bd.insert("partidas", null, registro);
        t = Toast.makeText(getApplicationContext(),"Datos guardados",Toast.LENGTH_SHORT);
        t.show();
        bd.close();
    }
    public void Volver(View v){
        finish();
    }
}
