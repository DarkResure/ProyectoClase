package com.example.juegopulsacion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public static String logged = "";
    private AdminSQL bd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuusuario, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id==R.id.log) {
            Intent l = new Intent(this, Login.class );
            startActivity(l);
        }
        return super.onOptionsItemSelected(item);
    }

    public void DarAlta(View v){
        Toast t = Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT);
        if(ComprobarUsuario()){
            if(logged.charAt(0) == 'A'){
                Intent l = new Intent(this, DarAlta.class );
                startActivity(l);
            }else{
                t = Toast.makeText(getApplicationContext(),"Identifíquese como Administrador para continuar",Toast.LENGTH_SHORT);
                t.show();
            }
        }else{
            t = Toast.makeText(getApplicationContext(),"Identifíquese en el icono de la parte superior derecha",Toast.LENGTH_SHORT);
            t.show();
        }

    }

    public void Jugar(View v){
        Toast t = Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT);
        if(ComprobarUsuario()){
            if(logged.charAt(0) == 'E'){
                Intent l = new Intent(this, Juegos.class );
                startActivity(l);
            }else{
                t = Toast.makeText(getApplicationContext(),"Identifíquese como Administrador para continuar",Toast.LENGTH_SHORT);
                t.show();
            }
        }else{
            t = Toast.makeText(getApplicationContext(),"Identifíquese en el icono de la parte superior derecha",Toast.LENGTH_SHORT);
            t.show();
        }

    }


    public void VerRegistros(View v){{
        Toast t = Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT);
        if(ComprobarUsuario()){
            if(logged.charAt(0) == 'M'){
                Intent l = new Intent(this, Registros.class);
                startActivity(l);
            }else{
                t = Toast.makeText(getApplicationContext(),"Identifíquese como Médico para continuar",Toast.LENGTH_SHORT);
                t.show();
            }
        }else{
            t = Toast.makeText(getApplicationContext(),"Identifíquese en el icono de la parte superior derecha",Toast.LENGTH_SHORT);
            t.show();
        }
    }}

    private static boolean ComprobarUsuario() {
        if(logged.equals("")){
            return false;
        }else{
            return true;
        }
    }
}
