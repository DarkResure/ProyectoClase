Usuarios:

Administrador: A-001
Médico: M-001
Enfermero: E-001

Paciente: P-001 - P-002